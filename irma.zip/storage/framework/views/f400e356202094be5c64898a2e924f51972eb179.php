<?php $__env->startSection('content'); ?>
    
<div class="flex flex-col items-center" >
  <?php echo $__env->make('dashboard.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="w-8/12 bg-white p-6 mb-10 rounded-lg">


    <h2 class="text-3xl">
      <?php echo e($lead->name); ?>      
    </h2>

    <div class="my-5">
      <span class="font-semibold mr-3">Date: </span><span><?php echo e($lead->created_at->toDayDateTimeString()); ?></span>
    </div>

    <div class="my-5">
      <span class="font-semibold mr-3">Email: </span> <span><?php echo e($lead->email); ?></span>
    </div>

    <div class="my-5">
      <span class="font-semibold mr-3">Phone: </span> <span><?php echo e($lead->phone); ?></span>
    </div>

    <?php if($lead->message): ?>
      <div class="my-5">
        <span class="font-semibold mr-3">Message: </span> <span><?php echo e($lead->message); ?></span>
      </div>        
    <?php endif; ?>

    <?php if($lead->referrer): ?>
      <div class="my-5">
        <span class="font-semibold mr-3">Event: </span> <span><?php echo e($lead->event); ?></span>
      </div>        
    <?php endif; ?>

    <div class="flex">
      <div>
        <form action="<?php echo e(route('lead.destroy', $lead->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 font-medium transition duration-150 ease-in-out" onclick="return confirm('Are you sure? This will forever delete this lead.')">Delete</button>
        </form>
      </div>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/dashboard/leads/show.blade.php ENDPATH**/ ?>