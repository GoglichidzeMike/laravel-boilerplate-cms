<?php $__env->startSection('content'); ?>
    
<div class="flex justify-center">
  <div class="w-8/12 bg-white p-6 my-6 rounded-lg">
      <div class="mb-4 p-3 border-2 flex flex-col justify-between">
        <h2 class="text-3xl mb-4"><?php echo e($blog->name); ?></h2>
        <img src="/uploads/image/<?php echo e($blog->image); ?>" class="mb-3 max-w-lg rounded-md shadow-md" alt="<?php echo e($blog->name); ?>">
        <div class="my-3">
          <?php echo $blog->body; ?>

        </div>
        <div class="flex flex-col mt-3">
          <a href="" class="font-bold"><?php echo e($blog->user->name); ?></a>
          <span class="text-gray-600 text-sm">  <?php echo e($blog->created_at->toFormattedDateString()); ?></span>
        </div>
      </div>    


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/blogs/show.blade.php ENDPATH**/ ?>