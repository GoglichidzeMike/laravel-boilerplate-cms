<?php $__env->startSection('content'); ?>
    
<div class="flex justify-center">
  <div class="w-8/12 bg-white p-6 rounded-lg">
    Home
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/home.blade.php ENDPATH**/ ?>