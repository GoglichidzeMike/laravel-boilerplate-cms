<?php $__env->startSection('content'); ?>
    


<div class="flex flex-col items-center" >
  <?php echo $__env->make('dashboard.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="w-10/12 bg-white p-6 rounded-lg">

    <div class="flex rounded-sm w-full bg-gray-100 mb-4 shadow">
      <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-6/12">Name</div>
      <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-2/12">Event Date</div>
      <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-2/12">Created at</div>
      <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 bborder-gray w-2/12">Something</div>
      <div class="rounded-sm p-1 rounded-sm border-2 border-r-0 bborder-gray">
        <div class="px-6 py-1 rounded">
          Edit
        </div>

      </div>
      <div class="rounded-sm p-1 rounded-sm border-2 border-gray">
        <div class="px-4 py-1 rounded">
          Delete
        </div>
      </div>
    </div>    


    <?php if($events->count()): ?>
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div class="flex rounded-sm w-full bg-gray-10 my-2 shadow-sm hover:shadow-md transition duration-150 ease-in-out">
        <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-6/12 flex justify-between"><a href="<?php echo e(route('event.show', $event->slug)); ?>"><?php echo e($event->name); ?></a> <img class="h-6 rounded-sm" src="<?php echo e(asset('/uploads/image/'.$event->image)); ?>" alt=""></div>
        <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-2/12">
         <?php if($event->date): ?>
          <?php echo e($event->date); ?>


         <?php else: ?>
          No date
         <?php endif; ?>
        </div>
        <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 border-gray w-2/12"><?php echo e($event->created_at->toFormattedDateString()); ?></div>
        <div class="rounded-sm p-2 rounded-sm border-2 border-r-0 bborder-gray w-2/12"><?php echo e($event->user->name); ?></div>
        <div class="rounded-sm p-1 rounded-sm border-2 border-r-0 bborder-gray"><a href="<?php echo e(route('event.edit', $event->id)); ?>">
          <div class="bg-blue-500 text-white px-6 py-1 rounded hover:bg-blue-700 font-medium transition duration-150 ease-in-out">Edit</div>
        </a></div>
        
        <div class="rounded-sm p-1 rounded-sm border-2 border-gray">
        <form action="<?php echo e(route('event.destroy', $event->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-700 font-medium transition duration-150 ease-in-out" onclick="return confirm('Are you sure? This will forever delete this event.')">Delete</button>
        </form>
        </div>
      </div>    
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($events->links()); ?>

        
    <?php else: ?>
      <p>There are no events to display</p>    
    <?php endif; ?>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/dashboard/events/index.blade.php ENDPATH**/ ?>