<?php $__env->startSection('content'); ?>
    
<div class="flex flex-col items-center" >
  <?php echo $__env->make('dashboard.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="w-8/12 bg-white p-6 mb-10 rounded-lg">


    <h2 class="text-3xl">
      <?php echo e($event->name); ?>      
    </h2>

    <div class="my-10">
      <img class="rounded-md max-w-sm shadow" src="<?php echo e(asset('/uploads/image/'.$event->image)); ?>" alt="<?php echo e($event->name); ?>">
    </div>

    <?php if($event->date): ?>
      <p>Event date: <?php echo e($event->date); ?></p>
    <?php endif; ?>

    <?php if($event->duration): ?>
      <p>Event duration: <?php echo e($event->duration); ?></p>
    <?php endif; ?>

    <div class="my-10">
      <?php echo $event->body; ?>

    </div>


    <div class="my-10">
      <?php echo $__env->make('dashboard.includes.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


    <div class="flex">
      <a class="bg-blue-500 text-white px-4 py-2 mr-5 rounded font-medium hover:bg-blue-700 transition duration-150 ease-in-out" href="<?php echo e(route('event.edit', $event->id)); ?>">Edit</a>
      <div>
        <form action="<?php echo e(route('event.destroy', $event->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 font-medium transition duration-150 ease-in-out" onclick="return confirm('Are you sure? This will forever delete this event post.')">Delete</button>
        </form>
      </div>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/dashboard/events/show.blade.php ENDPATH**/ ?>