<?php $__env->startSection('content'); ?>
    
<div class="flex flex-col items-center" >
  <?php echo $__env->make('dashboard.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="w-8/12 bg-white p-6 mb-10 rounded-lg">


    <h2 class="text-3xl">
      <?php echo e($blog->name); ?>      
    </h2>

    <div class="my-10">
      <img class="rounded-md max-w-sm shadow" src="<?php echo e(asset('/uploads/image/'.$blog->image)); ?>" alt="<?php echo e($blog->name); ?>">
    </div>

    <div class="my-10">
      <?php echo $blog->body; ?>

    </div>


    <div class="flex">
      <a class="bg-blue-500 text-white px-4 py-2 mr-5 rounded font-medium hover:bg-blue-700 transition duration-150 ease-in-out" href="<?php echo e(route('blog.edit', $blog->id)); ?>">Edit</a>
      <div>
        <form action="<?php echo e(route('blog.destroy', $blog->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 font-medium transition duration-150 ease-in-out" onclick="return confirm('Are you sure? This will forever delete this blog post.')">Delete</button>
        </form>
      </div>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/dashboard/blogs/show.blade.php ENDPATH**/ ?>