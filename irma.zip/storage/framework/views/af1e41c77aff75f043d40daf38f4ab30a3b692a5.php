<div>
  <h2 class="text-xl mb-4 text-gray-700" >
    Register for this event
  </h2>

  <?php if(session('status')): ?>
    <div class="mb-6 mx-auto w-8/12">
      <div class="mx-auto text-center text-green-700 font-medium">
        <?php echo e(session('status')); ?>

      </div>
    </div>
  <?php endif; ?>  

  <form action="<?php echo e(route('contact')); ?>" method="post" class="mb-4" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-10 flex flex-col">

      <label for="name" class="sr-only">Name</label>
      <input type="text" name="name" id="name" placeholder="Your Name"
        class="bg-gray-100 border-2 w-52 p-2 text-sm rounded-lg mb-4 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " 
        value="<?php echo e(old('name')); ?>">

      <label for="email" class="sr-only">Email</label>
      <input type="email" name="email" id="email" placeholder="Your Email"
        class="bg-gray-100 border-2 w-52 p-2 text-sm rounded-lg mb-4 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " 
        value="<?php echo e(old('email')); ?>">

      <label for="phone" class="sr-only">Phone</label>
      <input type="string" name="phone" id="phone" placeholder="Your Phone"
        class="bg-gray-100 border-2 w-52 p-2 text-sm rounded-lg mb-4 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " 
        value="<?php echo e(old('phone')); ?>">

      <label  class="hidden" for="referrer"></label>
      <input type="text" name="referrer" id="referrer" class="hidden" value="<?php echo e($event->slug); ?>">

      
      
      <div class="div">
        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded font-medium hover:bg-green-700">Register</button>
      </div>
    </div>
  </form>
</div><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/dashboard/includes/register.blade.php ENDPATH**/ ?>