<?php $__env->startSection('content'); ?>
    
<div class="flex justify-center">
  <div class="w-8/12 my-6 bg-white p-6 rounded-lg">

      <div class="mb-4 p-3 border-2 flex flex-col justify-between">
        <h2 class="text-3xl">
          <?php echo e($event->name); ?>      
        </h2>

        <div class="my-10">
          <img class="rounded-md max-w-sm shadow" src="<?php echo e(asset('/uploads/image/'.$event->image)); ?>" alt="<?php echo e($event->name); ?>">
        </div>

        <?php if($event->date): ?>
          <p>Event date: <?php echo e($event->date); ?></p>
        <?php endif; ?>

        <?php if($event->duration): ?>
          <p>Event duration: <?php echo e($event->duration); ?></p>
        <?php endif; ?>

        <div class="my-10">
          <?php echo $event->body; ?>

        </div>


        <div class="my-10">
          <?php echo $__env->make('dashboard.includes.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

      </div>    
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/events/show.blade.php ENDPATH**/ ?>