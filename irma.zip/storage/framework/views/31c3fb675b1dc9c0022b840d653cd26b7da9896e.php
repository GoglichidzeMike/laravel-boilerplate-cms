<?php $__env->startSection('content'); ?>
    
<div class="flex justify-center">
  <div class="w-8/12 bg-white p-6 rounded-lg">


    <div class="grid grid-cols-3 gap-4">
      <?php if($blogs->count()): ?>
      <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="mb-4 p-3 border-2 flex flex-col justify-between">
        <img src="/uploads/image/<?php echo e($blog->image); ?>" class="mb-3" alt="<?php echo e($blog->name); ?>">
        <a href="<?php echo e(route('public_blogs.show' , $blog->slug)); ?>"><h2><?php echo e($blog->name); ?></h2></a>

        <div class="flex flex-col mt-3">
          <a href="" class="font-bold"><?php echo e($blog->user->name); ?></a>
          <span class="text-gray-600 text-sm">  <?php echo e($blog->created_at->toFormattedDateString()); ?></span>
        </div>
        
      </div>    
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      <?php echo e($blogs->links()); ?>

      
      <?php else: ?>
      <p>There are no blogs</p>    
      <?php endif; ?>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mikael/12C2BD35C2BD1E43/Projects/Freelance/irma/resources/views/blogs/index.blade.php ENDPATH**/ ?>