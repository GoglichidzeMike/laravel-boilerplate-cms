@extends('layouts.app')

@section('content')
    
<div class="flex flex-col items-center" >
  <div class="w-8/12 bg-white p-6 rounded-lg mb-4">

    
  @include('dashboard.includes.contact')

  </div>
</div>

@endsection